%% Simple Text-to-Speech Simulation in MATLAB
clc; clear; close all;

%% Step 1: Original text
text = 'Dr. Smith will visit on 12/09/2024.';
disp('Original Text:');
disp(text);

%% Step 2: Normalize text (fix abbreviations and dates)
normalizedText = replace(text, 'Dr.', 'Doctor');
normalizedText = replace(normalizedText, '12/09/2024', 'twelfth of September, twenty twenty-four');
disp('Normalized Text:');
disp(normalizedText);

%% Step 3: Split text into words
tokens = split(normalizedText);
disp('Words:');
disp(tokens);

%% Step 4: Assign a frequency for each word
numWords = length(tokens);              % Number of words
wordFrequencies = 440 + (0:numWords-1)*40; % 440 Hz base, +40 Hz per word

%% Step 5: Generate and concatenate tones for each word
Fs = 44100;       % Sampling frequency
duration = 0.5;   % Each word lasts 0.5 seconds
speech = [];      % Initialize empty array

for i = 1:numWords
    t = 0:1/Fs:duration;                  % Time vector
    tone = sin(2*pi*wordFrequencies(i) * t); % Sine wave for the word
    speech = [speech, tone];              % Add to full speech
end
disp(speech);

%% Step 6: Play the synthesized speech
disp('Playing synthesized speech...');
sound(speech, Fs);

%% Step 7: Plot the waveform
figure;
plot(speech);
title('Synthesized Speech Waveform');
xlabel('Sample Number');
ylabel('Amplitude');
