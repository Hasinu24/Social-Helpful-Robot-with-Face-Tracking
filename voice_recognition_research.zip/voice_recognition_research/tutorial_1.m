%% ============================================
%   SPEECH RECOGNITION USING DTW + MFCC
%   NO AUDIO TOOLBOX REQUIRED
%   FULL WORKING SCRIPT
% ============================================

clc; clear; close all;

%% ============================
%  STEP 1: RECORD USER AUDIO
% ============================

Fs = 44100;        
nBits = 16;        
nChannels = 1;     
recDuration = 5;   

recObj = audiorecorder(Fs, nBits, nChannels);

disp('Start speaking...');
recordblocking(recObj, recDuration);
disp('Recording finished.');

audioData = getaudiodata(recObj);

audiowrite('speech_recording.wav', audioData, Fs);

figure;
plot(audioData);
title('Recorded Speech Signal');
xlabel('Sample');
ylabel('Amplitude');


%% ============================
%  STEP 2: RECORD REFERENCE WORD
% ============================

disp('Record the reference word (e.g., HELLO)...');

recObj = audiorecorder(Fs, nBits, nChannels);
recordblocking(recObj, 3);
disp('Reference recording finished.');

referenceAudio = getaudiodata(recObj);

audiowrite('hello_reference.wav', referenceAudio, Fs);

figure;
plot(referenceAudio);
title('Reference Audio Signal');
xlabel('Sample');
ylabel('Amplitude');


%% ============================
%  STEP 3: PREPROCESS AUDIO
% ============================

audioData = audioData / max(abs(audioData));

figure;
spectrogram(audioData, 256, 128, 256, Fs, 'yaxis');
title('Spectrogram of Recorded Audio');
xlabel('Time (s)');
ylabel('Frequency (Hz)');


%% ============================
%  STEP 4: EXTRACT MFCC FEATURES
% ============================

recordedMFCC = simple_mfcc(audioData, Fs);

figure;
imagesc(recordedMFCC.');
colorbar;
title('MFCC Features (Recorded Audio)');
xlabel('Frame');
ylabel('Coefficient');


%% ============================
%  STEP 5: MATCH USING DTW
% ============================

[referenceAudio, refFs] = audioread('hello_reference.wav');

if refFs ~= Fs
    referenceAudio = resample(referenceAudio, Fs, refFs);
end

referenceMFCC = simple_mfcc(referenceAudio, Fs);

minRows = min(size(referenceMFCC,1), size(recordedMFCC,1));
referenceMFCC = referenceMFCC(1:minRows, :);
recordedMFCC  = recordedMFCC(1:minRows, :);

distance = dtw(recordedMFCC, referenceMFCC);

disp(['DTW Distance to "HELLO": ', num2str(distance)]);

threshold = 10;

if distance < threshold
    disp('Matched Word: HELLO');
else
    disp('No Match Found.');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SIMPLE MFCC FUNCTION (NO TOOLBOX REQUIRED)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function coeffs = simple_mfcc(signal, Fs)

    signal = signal(:);

    %% Pre-emphasis
    pre_emphasis = 0.97;
    emphasized = filter([1 -pre_emphasis], 1, signal);

    %% Framing
    frame_size = 0.025;
    frame_stride = 0.010;

    frame_len = round(frame_size * Fs);
    frame_step = round(frame_stride * Fs);

    signal_len = length(emphasized);
    num_frames = floor((signal_len - frame_len) / frame_step) + 1;

    frames = zeros(num_frames, frame_len);

    for i = 1:num_frames
        start_idx = (i-1)*frame_step + 1;
        frames(i,:) = emphasized(start_idx:start_idx + frame_len - 1);
    end

    %% Windowing
    frames = frames .* hamming(frame_len)';

    %% FFT + Power Spectrum
    NFFT = 512;
    mag_frames = abs(fft(frames, NFFT, 2));
    pow_frames = (1/NFFT) * (mag_frames.^2);

    %% Mel Filterbank
    nfilt = 26;
    low_freq = 0;
    high_freq = 2595 * log10(1 + (Fs/2)/700);

    mel_points = linspace(low_freq, high_freq, nfilt + 2);
    hz_points = 700 * (10.^(mel_points/2595) - 1);

    bin = floor((NFFT+1) * hz_points / Fs);

    fbank = zeros(nfilt, NFFT/2 + 1);

    for m = 2:nfilt+1
        f_left = bin(m-1);
        f_center = bin(m);
        f_right = bin(m+1);

        for k = f_left:f_center
            fbank(m-1, k+1) = (k - bin(m-1)) / (bin(m) - bin(m-1));
        end
        for k = f_center:f_right
            fbank(m-1, k+1) = (bin(m+1) - k) / (bin(m+1) - bin(m));
        end
    end

    filter_banks = pow_frames(:,1:NFFT/2+1) * fbank';
    filter_banks(filter_banks == 0) = eps;
    filter_banks = log(filter_banks);

    %% DCT → MFCC
    num_ceps = 13;
    coeffs = dct(filter_banks, [], 2);
    coeffs = coeffs(:,1:num_ceps);

end
