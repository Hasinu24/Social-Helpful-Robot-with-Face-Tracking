function coeffs = getMFCC(signal, fs)

    signal = signal(:);  % ensure column vector

    % --------------------------
    % 1. PRE-EMPHASIS
    % --------------------------
    pre_emphasis = 0.97;
    emphasized = filter([1 -pre_emphasis], 1, signal);

    % --------------------------
    % 2. FRAMING
    % --------------------------
    frame_size = 0.025;   % 25 ms
    frame_stride = 0.010; % 10 ms
    frame_length = round(frame_size * fs);
    frame_step   = round(frame_stride * fs);

    signal_length = length(emphasized);

    % pad if too short
    if signal_length < frame_length
        emphasized(signal_length+1:frame_length) = 0;
        signal_length = length(emphasized);
    end

    num_frames = 1 + floor((signal_length - frame_length) / frame_step);

    frames = zeros(num_frames, frame_length);

    % --------------------------
    % Create frames safely
    % --------------------------
    for i = 1:num_frames
        start = (i-1)*frame_step + 1;
        stop  = start + frame_length - 1;

        if stop > signal_length
            % pad with zeros
            frame = zeros(frame_length,1);
            available = signal_length - start + 1;
            frame(1:available) = emphasized(start:signal_length);
        else
            frame = emphasized(start:stop);
        end

        frames(i,:) = frame' .* hamming(frame_length)';
    end

    % --------------------------
    % 3. FFT + POWER SPECTRUM
    % --------------------------
    NFFT = 512;
    mag_frames = abs(fft(frames, NFFT, 2));
    pow_frames = (1/NFFT) * (mag_frames.^2);

    % --------------------------
    % 4. MEL FILTERBANK
    % --------------------------
    nfilt = 26;
    low_freq = 0;
    high_freq = 2595 * log10(1 + (fs/2)/700);
    mel_points = linspace(low_freq, high_freq, nfilt+2);
    hz_points = 700 * (10.^(mel_points/2595)-1);

    bin = floor((NFFT+1) * hz_points / fs);

    fbank = zeros(nfilt, floor(NFFT/2+1));
    for m = 2:nfilt+1
        f_m_minus = bin(m-1);
        f_m       = bin(m);
        f_m_plus  = bin(m+1);

        for k = f_m_minus:f_m
            if k >= 1 && k <= floor(NFFT/2+1)
                fbank(m-1,k) = (k - f_m_minus) / (f_m - f_m_minus);
            end
        end

        for k = f_m:f_m_plus
            if k >= 1 && k <= floor(NFFT/2+1)
                fbank(m-1,k) = (f_m_plus - k) / (f_m_plus - f_m);
            end
        end
    end

    filter_banks = pow_frames(:,1:floor(NFFT/2+1)) * fbank';
    filter_banks(filter_banks == 0) = eps;

    filter_banks = 20 * log10(filter_banks);

    % --------------------------
    % 5. DCT → MFCC
    % --------------------------
    coeffs = dct(filter_banks, [], 2);
    coeffs = coeffs(:, 1:13); % first 13 MFCCs

end
